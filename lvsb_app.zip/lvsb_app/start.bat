@echo off
title LVSB Energy Report App
echo.
echo ==========================================
echo   LVSB Energy Report App
echo   กำลังเปิดระบบ...
echo ==========================================
echo.
cd /d "%~dp0"
python app.py
pause
